import { Component } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  name = '';
  age = 0;
  gender = '';
  phone = '';
  DT = -1; 
  SP = -1;
  TF = 0;

  members = 
  [
    { name: '', age: 0, gender: '', phone: '', diet: '', dietVal: 0, subPlan: '', subPlanVal: 0, TotalFees: 0 }
  ];

  subPlan = 
  [
    { value: 100, name: '1 month' },
    { value: 280, name: '3 month' },
    { value: 500, name: '6 month' }
  ];

  dietType = 
  [
    { value: 0, name: 'Normal Diet' },
    { value: 50, name: 'Low Carbs' },
    { value: 30, name: 'Low Fat' }
  ];

  async subscribe() {

    this.TF = this.subPlan[this.SP].value + this.dietType[this.DT].value;

    let alert = this.alertCtrl.create({
      header:'Subscription Details',
      message: `Name: ${this.name}<br><br>  Age: ${this.age}<br><br> Gender: ${this.gender}<br><br> Phone Number: ${this.phone}<br><br> Diet Type: ${this.dietType[this.DT].name}<br><br> Subscription Plan: ${this.subPlan[this.SP].name}<br><br> Total Fees: ${this.TF} BD`,
      buttons: ['OK', 'CANCEL']
    });
    (await alert).present();

  }

  constructor(public alertCtrl: AlertController) { }

}
