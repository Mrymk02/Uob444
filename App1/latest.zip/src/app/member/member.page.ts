import { Component, OnInit } from '@angular/core';
import { FbService } from '../fb.service';

@Component({
  selector: 'app-member',
  templateUrl: './member.page.html',
  styleUrls: ['./member.page.scss'],
})

export class MemberPage implements OnInit {

  memberID=0;
  memberFname="";
  memberLname="";
  memberAge="";
  memberGender="";
  memberMajor="";
  memberPhone=0;
  memberEmail="";

  constructor(public fbSrv: FbService) { }

  ngOnInit() { }


  register() 
  {
    const member = {id: "", fname: "", lname: "", age: "", gender: "", major: "", phone: "", email: ""};
    this.fbSrv.registerMember( member);
  }

  edit()
  {

  }

  delete()
  {

  }

}
